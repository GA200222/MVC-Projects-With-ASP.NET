﻿using System.Globalization;
using System.Xml;
using Homies.Data.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Type = Homies.Data.Models.Type;

namespace Homies.Data
{
    public class HomiesDbContext : IdentityDbContext
    {
        public HomiesDbContext(DbContextOptions<HomiesDbContext> options)
            : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder
                .Entity<Type>()
                .HasData(new Type()
                {
                    Id = 1,
                    Name = "Animals"
                },
                new Type()
                {
                    Id = 2,
                    Name = "Fun"
                },
                new Type()
                {
                    Id = 3,
                    Name = "Discussion"
                },
                new Type()
                {
                    Id = 4,
                    Name = "Work"
                });



            modelBuilder.Entity<Event>(entity =>
            {
                entity.Property(e => e.CreatedOn)
                      .HasColumnType("nvarchar(16)")
                      .HasMaxLength(16)
                      .HasConversion(
                          v => v.ToString("yyyy-MM-dd H:mm"),
                          v => DateTime.ParseExact(v, "yyyy-MM-dd H:mm", null)
                      );
            });

            modelBuilder.Entity<Event>(entity =>
            {
                entity.Property(e => e.Start)
                      .HasColumnType("nvarchar(16)")
                      .HasMaxLength(16)
                      .HasConversion(
                          v => v.ToString("yyyy-MM-dd H:mm"),
                          v => DateTime.ParseExact(v, "yyyy-MM-dd H:mm", null)
                      );
            });

            modelBuilder.Entity<Event>(entity =>
            {
                entity.Property(e => e.End)
                      .HasColumnType("nvarchar(16)")
                      .HasMaxLength(16)
                      .HasConversion(
                          v => v.ToString("yyyy-MM-dd H:mm"),
                          v => DateTime.ParseExact(v, "yyyy-MM-dd H:mm", null)
                      );
            });

            modelBuilder.Entity<EventParticipant>()
                .HasKey(x => new { x.HelperId, x.EventId });

            base.OnModelCreating(modelBuilder);
        }
        public DbSet<Event> Events { get; set; }
        public DbSet<Type> Types { get; set; }
        public DbSet<EventParticipant> EventParticipants { get; set; }
    }
}